package inicio;

import java.sql.*;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        // Establecer la conexión con la base de datos
        Connection con = ConexionDB.conectar();
        if (con != null) {
            boolean continuar = true;
            while (continuar) {
                System.out.println("\nMenú de opciones:");
                System.out.println("1. Crear tablas");
                System.out.println("2. Insertar datos");
                System.out.println("3. Modificar datos");
                System.out.println("4. Listar datos");
                System.out.println("5. Eliminar tablas");
                System.out.println("6. Eliminar un registro");
                System.out.println("7. Salir");
                System.out.print("Elige una opción: ");
                int opcion = sc.nextInt();
                sc.nextLine();
                
                if (opcion == 1) {
                    CRUD.crearTablas(con);
                } else if (opcion == 2) {
                    CRUD.insertarDatos(con);
                } else if (opcion == 3) {
                    CRUD.modificarDatos(con);
                } else if (opcion == 4) {
                    CRUD.listarDatos(con);
                } else if (opcion == 5) {
                    CRUD.eliminarTablas(con);
                } else if (opcion == 6) {
                    eliminarRegistro(con);
                } else if (opcion == 7) {
                    continuar = false;
                    ConexionDB.desconectar(con);
                } else {
                    System.out.println("\nOpción no válida. Intenta nuevamente.");
                }
            }
        } else {
            System.out.println("\nError al conectar con la base de datos.");
        }
    }

    // Eliminar un registro de cualquier tabla
    public static void eliminarRegistro(Connection con) {
        System.out.println("\n¿De qué tabla deseas eliminar un registro?");
        System.out.println("1. Pacientes");
        System.out.println("2. Medicamentos");
        System.out.println("3. Receta");
        System.out.print("Elige una opción: ");
        int opcion = sc.nextInt();
        sc.nextLine();

        if (opcion == 1) {
            CRUDPaciente.eliminarPaciente(con);
        } else if (opcion == 2) {
            CRUDMedicamento.eliminarMedicamento(con);
        } else if (opcion == 3) {
            CRUDReceta.eliminarReceta(con);
        } else {
            System.out.println("\nOpción no válida.");
        }
    }
}
